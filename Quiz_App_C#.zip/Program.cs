using System;
using System.Collections.Generic;
using SimpleQuizApp.Models;
using SimpleQuizApp.Services;

namespace SimpleQuizApp
{
    class Program
    {
        static void Main(string[] args)
        {
            // Define your questions here
            var questions = new List<QuizQuestion>
            {
                new QuizQuestion(
                    "What is the output of: Console.WriteLine(5 + 3 * 2);?",
                    new List<string> { "16", "11", "10", "13" },
                    correctOption: 1 // 5 + (3*2) = 11
                ),
                new QuizQuestion(
                    "Which keyword is used to define a subclass in C#?",
                    new List<string> { "extends", "inherits", ":", "base" },
                    correctOption: 2 // colon syntax
                ),
                new QuizQuestion(
                    "What does `static` keyword indicate for a method?",
                    new List<string>
                    {
                        "Method belongs to the class, not instance",
                        "Method is private",
                        "Method returns void",
                        "Method is asynchronous"
                    },
                    correctOption: 0
                ),
                new QuizQuestion(
                    "Which collection allows duplicate items in C#?",
                    new List<string> { "Dictionary<>", "List<>", "Hashtable", "HashSet<>" },
                    correctOption: 1 // List<> allows duplicates
                ),
                new QuizQuestion(
                    "Which of these is NOT a value type in C#?",
                    new List<string> { "int", "struct", "enum", "string" },
                    correctOption: 3
                )
            };

            var quiz = new QuizService(questions);
            quiz.Start();

            Console.WriteLine("Press any key to exit...");
            Console.ReadKey();
        }
    }
}
