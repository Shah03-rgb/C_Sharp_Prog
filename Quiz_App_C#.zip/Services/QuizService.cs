using System;
using System.Collections.Generic;
using SimpleQuizApp.Models;

namespace SimpleQuizApp.Services
{
    public class QuizService
    {
        private readonly List<QuizQuestion> _questions;

        public QuizService(List<QuizQuestion> questions)
        {
            _questions = questions;
        }

        public void Start()
        {
            int score = 0;
            Console.WriteLine("Welcome to the C# Simple Quiz App!\n");

            for (int i = 0; i < _questions.Count; i++)
            {
                var q = _questions[i];
                Console.WriteLine($"Question {i + 1}: {q.QuestionText}");
                for (int j = 0; j < q.Options.Count; j++)
                    Console.WriteLine($"  {j + 1}. {q.Options[j]}");

                int userChoice = GetUserChoice(q.Options.Count);
                if (userChoice - 1 == q.CorrectOption)
                {
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine("Correct!\n");
                    score++;
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine($"Wrong! Correct answer: {q.Options[q.CorrectOption]}\n");
                }
                Console.ResetColor();
            }

            Console.WriteLine($"Quiz Over! Your score: {score} / {_questions.Count}");
        }

        private int GetUserChoice(int optionCount)
        {
            int choice;
            while (true)
            {
                Console.Write($"Enter your choice (1-{optionCount}): ");
                var input = Console.ReadLine();
                if (int.TryParse(input, out choice) && choice >= 1 && choice <= optionCount)
                    return choice;
                Console.WriteLine($"Invalid input. Please enter a number between 1 and {optionCount}.");
            }
        }
    }
}
