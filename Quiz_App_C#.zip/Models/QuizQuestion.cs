using System.Collections.Generic;

namespace SimpleQuizApp.Models
{
    public class QuizQuestion
    {
        public string QuestionText { get; set; }
        public List<string> Options { get; set; }
        public int CorrectOption { get; set; }  // zero-based index

        public QuizQuestion(string questionText, List<string> options, int correctOption)
        {
            QuestionText = questionText;
            Options = options;
            CorrectOption = correctOption;
        }
    }
}
